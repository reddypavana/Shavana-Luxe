import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { z } from "zod";

const emailSchema = z.string().trim().email("Valid email required").max(255);
const passwordSchema = z.string().min(6, "Password must be at least 6 characters").max(128);

const Login = () => {
  const { signIn, signUp, user } = useAuth();
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  if (user) {
    navigate("/", { replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const emailResult = emailSchema.safeParse(form.email);
    const passResult = passwordSchema.safeParse(form.password);
    const fieldErrors: Record<string, string> = {};
    if (!emailResult.success) fieldErrors.email = emailResult.error.errors[0].message;
    if (!passResult.success) fieldErrors.password = passResult.error.errors[0].message;
    if (Object.keys(fieldErrors).length) { setErrors(fieldErrors); return; }

    setLoading(true);
    if (isLogin) {
      const { error } = await signIn(form.email, form.password);
      if (error) {
        toast.error(error.message || "Sign in failed");
      } else {
        toast.success("Welcome back!");
        navigate("/");
      }
    } else {
      const { error } = await signUp(form.email, form.password);
      if (error) {
        toast.error(error.message || "Sign up failed");
      } else {
        toast.success("Account created! Please check your email to verify.");
      }
    }
    setLoading(false);
  };

  const inputClass = (field: string) =>
    `w-full border rounded-sm px-3 py-2.5 font-body text-sm bg-transparent text-foreground ${errors[field] ? "border-destructive" : "border-border"}`;

  return (
    <div className="min-h-screen flex items-center justify-center bg-champagne">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-card border border-border rounded-sm p-8 mx-4"
      >
        <div className="text-center mb-8">
          <Link to="/">
            <h2 className="font-display text-3xl font-semibold">
              <span className="text-gold">Shavana</span> Luxe
            </h2>
          </Link>
          <p className="font-body text-muted-foreground mt-2">
            {isLogin ? "Welcome back" : "Create your account"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Email</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => { setForm({ ...form, email: e.target.value }); setErrors({ ...errors, email: "" }); }}
              className={inputClass("email")}
              placeholder="your@email.com"
            />
            {errors.email && <p className="text-destructive text-xs mt-1 font-body">{errors.email}</p>}
          </div>
          <div>
            <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Password</label>
            <input
              type="password"
              value={form.password}
              onChange={(e) => { setForm({ ...form, password: e.target.value }); setErrors({ ...errors, password: "" }); }}
              className={inputClass("password")}
              placeholder="••••••••"
            />
            {errors.password && <p className="text-destructive text-xs mt-1 font-body">{errors.password}</p>}
          </div>

          {isLogin && (
            <Link to="/forgot-password" className="font-body text-xs text-gold hover:underline block text-right">
              Forgot password?
            </Link>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm py-6 hover:opacity-90 border-none disabled:opacity-50"
          >
            {loading ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
          </Button>
        </form>

        <p className="text-center font-body text-sm text-muted-foreground mt-6">
          {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
          <button onClick={() => { setIsLogin(!isLogin); setErrors({}); }} className="text-gold hover:underline font-medium">
            {isLogin ? "Sign Up" : "Sign In"}
          </button>
        </p>
      </motion.div>
    </div>
  );
};

export default Login;
