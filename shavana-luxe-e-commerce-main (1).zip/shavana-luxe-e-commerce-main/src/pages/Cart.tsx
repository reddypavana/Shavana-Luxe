import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";

const Cart = () => {
  const { items, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart();
  const [couponCode, setCouponCode] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [discount, setDiscount] = useState(0);

  const applyCoupon = () => {
    if (couponCode.toUpperCase() === "SHINE30") {
      const jewelleryTotal = items
        .filter((i) => i.product.category === "jewellery")
        .reduce((sum, i) => sum + i.product.price * i.quantity, 0);
      setDiscount(Math.round(jewelleryTotal * 0.3));
      setCouponApplied(true);
      toast.success("Coupon applied! 30% off on jewellery items.");
    } else {
      toast.error("Invalid coupon code");
    }
  };

  const shipping = totalPrice >= 1999 ? 0 : 99;
  const finalTotal = totalPrice - discount + shipping;

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <ShoppingBag size={64} className="mx-auto text-muted-foreground mb-6" />
          <h2 className="font-display text-3xl text-foreground mb-2">Your Cart is Empty</h2>
          <p className="font-body text-muted-foreground mb-8">Looks like you haven't added anything yet.</p>
          <Link to="/products">
            <Button className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm px-8 py-6 hover:opacity-90 border-none">
              Start Shopping
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="bg-champagne py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-semibold text-foreground">Shopping Cart</h1>
          <p className="font-body text-muted-foreground mt-2">{items.length} items</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Link
          to="/products"
          className="inline-flex items-center gap-2 font-body text-sm text-muted-foreground hover:text-foreground mb-8"
        >
          <ArrowLeft size={14} /> Continue Shopping
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map(({ product, quantity }) => (
              <div key={product.id} className="flex gap-4 p-4 bg-card rounded-sm border border-border">
                <Link to={`/product/${product.id}`} className="flex-shrink-0 w-24 h-24 overflow-hidden rounded-sm bg-secondary">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="font-display text-lg font-medium text-foreground truncate hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                  </Link>
                  <p className="font-body text-xs uppercase tracking-wider text-muted-foreground">{product.category}</p>
                  <p className="font-body font-semibold text-foreground mt-1">₹{product.price.toLocaleString()}</p>
                </div>
                <div className="flex flex-col items-end justify-between">
                  <button
                    onClick={() => removeFromCart(product.id)}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    aria-label="Remove"
                  >
                    <Trash2 size={16} />
                  </button>
                  <div className="flex items-center border border-border rounded-sm">
                    <button onClick={() => updateQuantity(product.id, quantity - 1)} className="p-1.5">
                      <Minus size={12} />
                    </button>
                    <span className="font-body text-sm w-8 text-center">{quantity}</span>
                    <button onClick={() => updateQuantity(product.id, quantity + 1)} className="p-1.5">
                      <Plus size={12} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="bg-card border border-border rounded-sm p-6 h-fit sticky top-32">
            <h3 className="font-display text-xl font-semibold text-foreground mb-6">Order Summary</h3>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between font-body text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">₹{totalPrice.toLocaleString()}</span>
              </div>
              {couponApplied && (
                <div className="flex justify-between font-body text-sm">
                  <span className="text-gold">Coupon Discount</span>
                  <span className="text-gold">-₹{discount.toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between font-body text-sm">
                <span className="text-muted-foreground">Shipping</span>
                <span className="text-foreground">{shipping === 0 ? "Free" : `₹${shipping}`}</span>
              </div>
              <div className="border-t border-border pt-3 flex justify-between">
                <span className="font-display text-lg font-semibold text-foreground">Total</span>
                <span className="font-display text-lg font-semibold text-foreground">₹{finalTotal.toLocaleString()}</span>
              </div>
            </div>

            {/* Coupon */}
            {!couponApplied && (
              <div className="flex gap-2 mb-6">
                <input
                  type="text"
                  placeholder="Coupon code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 border border-border rounded-sm px-3 py-2 font-body text-sm bg-transparent text-foreground placeholder:text-muted-foreground"
                />
                <Button
                  onClick={applyCoupon}
                  variant="outline"
                  className="font-body text-sm uppercase tracking-wider"
                >
                  Apply
                </Button>
              </div>
            )}

            <Link to="/checkout">
              <Button className="w-full gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm py-6 hover:opacity-90 border-none">
                Proceed to Checkout
              </Button>
            </Link>

            {totalPrice < 1999 && (
              <p className="text-center font-body text-xs text-muted-foreground mt-3">
                Add ₹{(1999 - totalPrice).toLocaleString()} more for free shipping!
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
