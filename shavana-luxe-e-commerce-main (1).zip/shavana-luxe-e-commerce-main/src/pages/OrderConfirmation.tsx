import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { CheckCircle, Package, Truck, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";

interface OrderData {
  order_number: string;
  status: string;
  total_amount: number;
  shipping_amount: number;
  estimated_delivery: string | null;
  created_at: string;
  shipping_name: string;
  shipping_email: string;
}

const statusSteps = ["paid", "processing", "shipped", "delivered"];
const statusLabels: Record<string, string> = {
  paid: "Payment Confirmed",
  processing: "Processing",
  shipped: "Shipped",
  delivered: "Delivered",
};

function getStatusProgress(status: string): number {
  const idx = statusSteps.indexOf(status);
  if (idx === -1) return 0;
  return ((idx + 1) / statusSteps.length) * 100;
}

const OrderConfirmation = () => {
  const [searchParams] = useSearchParams();
  const orderNumber = searchParams.get("order");
  const [order, setOrder] = useState<OrderData | null>(null);

  useEffect(() => {
    if (orderNumber) {
      supabase
        .from("orders")
        .select("order_number, status, total_amount, shipping_amount, estimated_delivery, created_at, shipping_name, shipping_email")
        .eq("order_number", orderNumber)
        .single()
        .then(({ data }) => {
          if (data) setOrder(data as OrderData);
        });
    }
  }, [orderNumber]);

  return (
    <div className="min-h-screen flex items-center justify-center py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center max-w-lg mx-auto px-4"
      >
        <CheckCircle size={80} className="mx-auto text-gold mb-6" />
        <h1 className="font-display text-4xl font-semibold text-foreground mb-3">Order Confirmed!</h1>
        <p className="font-body text-muted-foreground mb-2">
          Thank you for shopping with Shavana Luxe.
        </p>

        {order ? (
          <div className="mt-8 text-left bg-card border border-border rounded-sm p-6 space-y-5">
            <div className="flex justify-between items-center font-body text-sm">
              <span className="text-muted-foreground">Order Number</span>
              <span className="font-semibold text-foreground">{order.order_number}</span>
            </div>
            <div className="flex justify-between items-center font-body text-sm">
              <span className="text-muted-foreground">Total Paid</span>
              <span className="font-semibold text-foreground">
                ₹{(Number(order.total_amount) + Number(order.shipping_amount)).toLocaleString()}
              </span>
            </div>
            {order.estimated_delivery && (
              <div className="flex justify-between items-center font-body text-sm">
                <span className="text-muted-foreground flex items-center gap-1"><Calendar size={14} /> Est. Delivery</span>
                <span className="text-foreground">
                  {new Date(order.estimated_delivery).toLocaleDateString("en-IN", {
                    day: "numeric", month: "short", year: "numeric",
                  })}
                </span>
              </div>
            )}

            {/* Tracking Progress */}
            <div className="pt-4 border-t border-border">
              <p className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-3">Order Status</p>
              <Progress value={getStatusProgress(order.status)} className="h-2 mb-3" />
              <div className="flex justify-between font-body text-[10px] text-muted-foreground">
                {statusSteps.map((s) => (
                  <span
                    key={s}
                    className={order.status === s || statusSteps.indexOf(order.status) >= statusSteps.indexOf(s) ? "text-primary font-semibold" : ""}
                  >
                    {statusLabels[s]}
                  </span>
                ))}
              </div>
            </div>

            <p className="font-body text-xs text-muted-foreground">
              A confirmation has been sent to <strong>{order.shipping_email}</strong>.
            </p>
          </div>
        ) : (
          <p className="font-body text-sm text-muted-foreground mb-8">
            Your order has been placed successfully. You'll receive a confirmation email shortly.
          </p>
        )}

        <div className="flex gap-4 justify-center mt-8">
          <Link to="/orders">
            <Button variant="outline" className="font-body uppercase tracking-wider text-sm px-8 py-6">
              <Package size={16} className="mr-2" /> My Orders
            </Button>
          </Link>
          <Link to="/products">
            <Button className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm px-8 py-6 hover:opacity-90 border-none">
              Continue Shopping
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default OrderConfirmation;
