import { useParams, Link } from "react-router-dom";
import { ShoppingBag, Star, ArrowLeft, Minus, Plus, Truck, Shield, RotateCcw } from "lucide-react";
import { useState } from "react";
import { getProductById, getProductsByCategory } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/ProductCard";
import { toast } from "sonner";
import { motion } from "framer-motion";

const ProductDetail = () => {
  const { id } = useParams();
  const product = getProductById(id || "");
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-3xl text-foreground mb-4">Product Not Found</h2>
          <Link to="/products" className="font-body text-primary hover:underline">
            Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  const relatedProducts = getProductsByCategory(product.category)
    .filter((p) => p.id !== product.id)
    .slice(0, 4);

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) addToCart(product);
    toast.success(`${quantity}x ${product.name} added to cart`);
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <Link
          to="/products"
          className="inline-flex items-center gap-2 font-body text-sm text-muted-foreground hover:text-foreground mb-8"
        >
          <ArrowLeft size={14} />
          Back to Shop
        </Link>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-16">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="aspect-square overflow-hidden rounded-sm bg-secondary"
          >
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </motion.div>

          {/* Details */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col"
          >
            <p className="font-body text-xs uppercase tracking-[0.3em] text-gold mb-2">{product.category}</p>
            <h1 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-3">{product.name}</h1>

            <div className="flex items-center gap-2 mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={i < Math.floor(product.rating) ? "fill-gold text-gold" : "text-border"}
                  />
                ))}
              </div>
              <span className="font-body text-sm text-muted-foreground">
                {product.rating} ({product.reviews} reviews)
              </span>
            </div>

            <div className="flex items-baseline gap-3 mb-6">
              <span className="font-display text-3xl font-semibold text-foreground">
                ₹{product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <>
                  <span className="font-body text-lg text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                  <span className="font-body text-sm text-destructive font-medium">{discount}% OFF</span>
                </>
              )}
            </div>

            <p className="font-body text-muted-foreground leading-relaxed mb-8">{product.description}</p>

            {/* Quantity */}
            <div className="flex items-center gap-4 mb-6">
              <span className="font-body text-sm uppercase tracking-wider text-muted-foreground">Qty</span>
              <div className="flex items-center border border-border rounded-sm">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 hover:bg-secondary transition-colors"
                >
                  <Minus size={16} />
                </button>
                <span className="font-body w-12 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="p-2 hover:bg-secondary transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>
              <span className="font-body text-xs text-muted-foreground">
                {product.stock <= 5 ? `Only ${product.stock} left!` : "In Stock"}
              </span>
            </div>

            {/* Add to cart */}
            <Button
              onClick={handleAddToCart}
              className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm py-6 hover:opacity-90 transition-opacity border-none w-full md:w-auto"
            >
              <ShoppingBag size={18} className="mr-2" />
              Add to Cart — ₹{(product.price * quantity).toLocaleString()}
            </Button>

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 mt-10 pt-8 border-t border-border">
              {[
                { icon: Truck, label: "Free Shipping", sub: "Above ₹1999" },
                { icon: Shield, label: "Secure Payment", sub: "100% Protected" },
                { icon: RotateCcw, label: "Easy Returns", sub: "7-Day Policy" },
              ].map(({ icon: Icon, label, sub }) => (
                <div key={label} className="text-center">
                  <Icon size={20} className="mx-auto mb-2 text-gold" />
                  <p className="font-body text-xs font-medium text-foreground">{label}</p>
                  <p className="font-body text-[10px] text-muted-foreground">{sub}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="mt-20">
            <h2 className="font-display text-3xl font-semibold text-foreground mb-8">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
