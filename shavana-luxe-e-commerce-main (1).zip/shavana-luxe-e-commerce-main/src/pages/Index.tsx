import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/ProductCard";
import { products, categories } from "@/data/products";
import heroBanner from "@/assets/hero-banner.png";
import categoryJewellery from "@/assets/category-jewellery.png";
import categoryKurtis from "@/assets/category-kurtis.png";
import categorySarees from "@/assets/category-sarees.png";
import categoryTops from "@/assets/category-tops.png";

const categoryImages: Record<string, string> = {
  jewellery: categoryJewellery,
  kurtis: categoryKurtis,
  sarees: categorySarees,
  tops: categoryTops,
};

const Index = () => {
  const featuredProducts = products.filter((p) => p.isBestseller).slice(0, 4);
  const newArrivals = products.filter((p) => p.isNew).slice(0, 4);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[85vh] min-h-[600px] overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroBanner} alt="Shavana Luxe Collection" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/70 via-foreground/40 to-transparent" />
        </div>
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-lg"
          >
            <p className="font-body text-gold-light text-sm uppercase tracking-[0.3em] mb-4">
              New Collection 2026
            </p>
            <h2 className="font-display text-5xl md:text-6xl lg:text-7xl font-semibold text-background leading-[1.1] mb-6">
              Elegance
              <br />
              Redefined
            </h2>
            <p className="font-body text-background/80 text-lg mb-8 leading-relaxed">
              Discover premium artificial jewellery and curated fashion that celebrates the beauty of every Indian woman.
            </p>
            <div className="flex gap-4">
              <Link to="/products">
                <Button className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm px-8 py-6 hover:opacity-90 transition-opacity border-none">
                  Shop Now <ArrowRight size={16} className="ml-2" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <p className="font-body text-gold text-sm uppercase tracking-[0.3em] mb-2">Explore</p>
            <h2 className="font-display text-4xl font-semibold text-foreground">Shop by Category</h2>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={`/products?category=${cat.slug}`}
                  className="group block relative aspect-square overflow-hidden rounded-sm"
                >
                  <img
                    src={categoryImages[cat.slug]}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-foreground/30 group-hover:bg-foreground/40 transition-colors" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <h3 className="font-display text-2xl md:text-3xl font-semibold text-background">
                      {cat.name}
                    </h3>
                    <span className="font-body text-xs text-background/80 uppercase tracking-wider mt-1 group-hover:underline">
                      Shop Now
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bestsellers */}
      <section className="py-20 bg-champagne">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="font-body text-gold text-sm uppercase tracking-[0.3em] mb-2">Most Loved</p>
              <h2 className="font-display text-4xl font-semibold text-foreground">Bestsellers</h2>
            </div>
            <Link
              to="/products"
              className="font-body text-sm uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
            >
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-foreground rounded-sm p-12 md:p-20 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <p className="font-body text-gold text-sm uppercase tracking-[0.3em] mb-4">Limited Time Offer</p>
              <h2 className="font-display text-4xl md:text-5xl font-semibold text-background mb-4">
                Flat 30% Off on Jewellery
              </h2>
              <p className="font-body text-background/70 mb-8 max-w-md mx-auto">
                Use code <span className="text-gold font-semibold">SHINE30</span> at checkout. Valid on all jewellery collections.
              </p>
              <Link to="/products?category=jewellery">
                <Button className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm px-8 py-6 hover:opacity-90 transition-opacity border-none">
                  Shop Jewellery
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-20 bg-champagne">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="font-body text-gold text-sm uppercase tracking-[0.3em] mb-2">Just In</p>
              <h2 className="font-display text-4xl font-semibold text-foreground">New Arrivals</h2>
            </div>
            <Link
              to="/products"
              className="font-body text-sm uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors flex items-center gap-2"
            >
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {newArrivals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
