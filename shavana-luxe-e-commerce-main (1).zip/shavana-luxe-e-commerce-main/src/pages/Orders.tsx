import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Package, Truck, Calendar, Search, CheckCircle, BoxIcon, PackageCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/context/AuthContext";

interface Order {
  id: string;
  order_number: string;
  status: string;
  total_amount: number;
  shipping_amount: number;
  payment_method: string;
  estimated_delivery: string | null;
  courier_tracking_id: string | null;
  courier_name: string | null;
  created_at: string;
}

const trackingSteps = [
  { key: "confirmed", label: "Confirmed", icon: CheckCircle },
  { key: "processing", label: "Packed", icon: BoxIcon },
  { key: "shipped", label: "Shipped", icon: Truck },
  { key: "delivered", label: "Delivered", icon: PackageCheck },
];

const statusLabels: Record<string, string> = {
  pending: "Pending", confirmed: "Confirmed", paid: "Paid", processing: "Packed",
  shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled", failed: "Failed",
};

const statusColors: Record<string, string> = {
  pending: "bg-secondary text-secondary-foreground",
  confirmed: "bg-primary/10 text-primary",
  paid: "bg-primary/15 text-primary",
  processing: "bg-accent/20 text-accent-foreground",
  shipped: "bg-primary/25 text-primary",
  delivered: "bg-primary text-primary-foreground",
  cancelled: "bg-destructive/10 text-destructive",
  failed: "bg-destructive/10 text-destructive",
};

function getStepIndex(status: string): number {
  // Map paid to confirmed level
  const mapped = status === "paid" ? "confirmed" : status;
  return trackingSteps.findIndex(s => s.key === mapped);
}

const Orders = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [trackingSearch, setTrackingSearch] = useState("");

  useEffect(() => { fetchOrders(); }, [user]);

  const fetchOrders = async () => {
    if (!user) { setLoading(false); return; }
    const { data } = await supabase
      .from("orders")
      .select("id, order_number, status, total_amount, shipping_amount, payment_method, estimated_delivery, courier_tracking_id, courier_name, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    if (data) setOrders(data as Order[]);
    setLoading(false);
  };

  const searchByTracking = async () => {
    if (!trackingSearch.trim()) { fetchOrders(); return; }
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("orders")
      .select("id, order_number, status, total_amount, shipping_amount, payment_method, estimated_delivery, courier_tracking_id, courier_name, created_at")
      .eq("user_id", user.id)
      .or(`order_number.ilike.%${trackingSearch}%,courier_tracking_id.ilike.%${trackingSearch}%`)
      .order("created_at", { ascending: false });
    if (data) setOrders(data as Order[]);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse font-body text-muted-foreground">Loading orders...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="bg-champagne py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-semibold text-foreground">My Orders</h1>
          <p className="font-body text-muted-foreground mt-2">Track and manage your orders</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex gap-2 mb-8 max-w-md">
          <input
            value={trackingSearch}
            onChange={(e) => setTrackingSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && searchByTracking()}
            placeholder="Search by order or tracking ID"
            className="flex-1 border border-border rounded-sm px-3 py-2 font-body text-sm bg-transparent text-foreground placeholder:text-muted-foreground"
          />
          <Button variant="outline" size="icon" onClick={searchByTracking}>
            <Search size={16} />
          </Button>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-20">
            <Package size={64} className="mx-auto text-muted-foreground/30 mb-4" />
            <h2 className="font-display text-2xl text-foreground mb-2">No orders yet</h2>
            <p className="font-body text-muted-foreground mb-6">Start shopping to see your orders here.</p>
            <Link to="/products">
              <Button className="gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm px-8 py-6 hover:opacity-90 border-none">Browse Products</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => {
              const currentStep = getStepIndex(order.status);
              const showTracker = currentStep >= 0;

              return (
                <div key={order.id} className="bg-card border border-border rounded-sm p-5">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="font-display text-lg font-semibold text-foreground">{order.order_number}</h3>
                        <span className={`px-2 py-0.5 rounded-sm text-xs font-body font-medium ${statusColors[order.status] || statusColors.pending}`}>
                          {statusLabels[order.status] || order.status}
                        </span>
                        <span className="font-body text-xs text-muted-foreground">{order.payment_method === "cod" ? "Cash on Delivery" : "Online Payment"}</span>
                      </div>
                      <p className="font-body text-xs text-muted-foreground">
                        Placed on {new Date(order.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                      </p>
                    </div>
                    <div className="font-display text-lg font-semibold text-foreground">
                      ₹{(Number(order.total_amount) + Number(order.shipping_amount)).toLocaleString()}
                    </div>
                  </div>

                  {/* Step Progress Bar */}
                  {showTracker && (
                    <div className="border-t border-border pt-4">
                      <div className="flex items-center justify-between relative">
                        {/* Connecting line */}
                        <div className="absolute top-5 left-[10%] right-[10%] h-0.5 bg-border" />
                        <div className="absolute top-5 left-[10%] h-0.5 bg-primary transition-all" style={{ width: `${currentStep >= 0 ? (currentStep / (trackingSteps.length - 1)) * 80 : 0}%` }} />

                        {trackingSteps.map((step, idx) => {
                          const isActive = idx <= currentStep;
                          const Icon = step.icon;
                          return (
                            <div key={step.key} className="flex flex-col items-center z-10 flex-1">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${isActive ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
                                <Icon size={18} />
                              </div>
                              <span className={`font-body text-[10px] mt-1.5 ${isActive ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                                {step.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Delivery info */}
                  <div className="flex flex-wrap gap-4 mt-4 font-body text-xs text-muted-foreground">
                    {order.estimated_delivery && (
                      <span className="flex items-center gap-1">
                        <Calendar size={12} />
                        Est. delivery: {new Date(order.estimated_delivery).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                      </span>
                    )}
                    {order.courier_tracking_id && (
                      <span className="flex items-center gap-1">
                        <Truck size={12} />
                        {order.courier_name || "Courier"}: {order.courier_tracking_id}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;
