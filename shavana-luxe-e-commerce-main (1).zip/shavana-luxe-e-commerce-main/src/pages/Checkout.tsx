import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, CreditCard, Loader2, Banknote } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";

const RAZORPAY_SCRIPT_URL = "https://checkout.razorpay.com/v1/checkout.js";

const addressSchema = z.object({
  fullName: z.string().trim().min(2, "Name is required").max(100),
  phone: z.string().trim().min(10, "Valid phone required").max(15),
  email: z.string().trim().email("Valid email required").max(255),
  address: z.string().trim().min(5, "Address is required").max(500),
  city: z.string().trim().min(2, "City is required").max(100),
  state: z.string().trim().min(2, "State is required").max(100),
  pincode: z.string().trim().min(6, "Valid pincode required").max(6),
});

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (document.querySelector(`script[src="${RAZORPAY_SCRIPT_URL}"]`)) { resolve(true); return; }
    const script = document.createElement("script");
    script.src = RAZORPAY_SCRIPT_URL;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

type PaymentMethod = "razorpay" | "cod";

const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: "", phone: "", email: "", address: "", city: "", state: "", pincode: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("razorpay");

  const shipping = totalPrice >= 1999 ? 0 : 99;
  const finalTotal = totalPrice + shipping;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const getOrderBody = () => ({
    amount: finalTotal,
    currency: "INR",
    shipping,
    shippingAddress: form,
    items: items.map(({ product, quantity }) => ({
      productId: product.id,
      productName: product.name,
      productPrice: product.price,
      productImage: product.image,
      quantity,
    })),
  });

  const handleCOD = async () => {
    setIsProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke("create-cod-order", { body: getOrderBody() });
      if (error || !data?.success) {
        toast.error("Failed to place COD order. Please try again.");
        setIsProcessing(false);
        return;
      }
      toast.success("Order placed successfully! 🎉");
      clearCart();
      navigate(`/order-confirmation?order=${data.orderNumber}`);
    } catch {
      toast.error("Something went wrong.");
      setIsProcessing(false);
    }
  };

  const handleRazorpay = async () => {
    setIsProcessing(true);
    try {
      const loaded = await loadRazorpayScript();
      if (!loaded) { toast.error("Failed to load payment gateway."); setIsProcessing(false); return; }

      const { data, error } = await supabase.functions.invoke("create-razorpay-order", { body: getOrderBody() });
      if (error || !data?.razorpayOrderId) { toast.error("Failed to create order."); setIsProcessing(false); return; }

      const options = {
        key: data.keyId,
        amount: data.amount,
        currency: data.currency,
        name: "Shavana Luxe",
        description: `Order ${data.orderNumber}`,
        order_id: data.razorpayOrderId,
        prefill: { name: form.fullName, email: form.email, contact: form.phone },
        theme: { color: "#b8860b" },
        handler: async (response: any) => {
          const { data: verifyData, error: verifyError } = await supabase.functions.invoke("verify-razorpay-payment", {
            body: {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              order_id: data.orderId,
            },
          });
          if (verifyError || !verifyData?.success) {
            toast.error("Payment verification failed. Contact support if amount was deducted.");
            setIsProcessing(false);
            return;
          }
          toast.success("Payment successful! 🎉");
          clearCart();
          navigate(`/order-confirmation?order=${verifyData.orderNumber}`);
        },
        modal: { ondismiss: () => { toast.error("Payment was cancelled."); setIsProcessing(false); } },
      };
      const razorpay = new (window as any).Razorpay(options);
      razorpay.on("payment.failed", (response: any) => { toast.error(`Payment failed: ${response.error.description}`); setIsProcessing(false); });
      razorpay.open();
    } catch {
      toast.error("Something went wrong.");
      setIsProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = addressSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => { if (err.path[0]) fieldErrors[err.path[0] as string] = err.message; });
      setErrors(fieldErrors);
      return;
    }
    if (paymentMethod === "cod") handleCOD();
    else handleRazorpay();
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-3xl text-foreground mb-4">No items to checkout</h2>
          <Link to="/products" className="font-body text-primary hover:underline">Go Shopping</Link>
        </div>
      </div>
    );
  }

  const inputClass = (field: string) =>
    `w-full border rounded-sm px-3 py-2.5 font-body text-sm bg-transparent text-foreground placeholder:text-muted-foreground ${errors[field] ? "border-destructive" : "border-border"}`;

  return (
    <div className="min-h-screen">
      <div className="bg-champagne py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-display text-4xl font-semibold text-foreground">Checkout</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Link to="/cart" className="inline-flex items-center gap-2 font-body text-sm text-muted-foreground hover:text-foreground mb-8">
          <ArrowLeft size={14} /> Back to Cart
        </Link>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Shipping Form */}
              <div className="bg-card border border-border rounded-sm p-6">
                <h3 className="font-display text-xl font-semibold text-foreground mb-6">Shipping Address</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Full Name *</label>
                    <input name="fullName" value={form.fullName} onChange={handleChange} className={inputClass("fullName")} placeholder="Enter your full name" />
                    {errors.fullName && <p className="text-destructive text-xs mt-1 font-body">{errors.fullName}</p>}
                  </div>
                  <div>
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Phone *</label>
                    <input name="phone" value={form.phone} onChange={handleChange} className={inputClass("phone")} placeholder="+91 98765 43210" />
                    {errors.phone && <p className="text-destructive text-xs mt-1 font-body">{errors.phone}</p>}
                  </div>
                  <div className="md:col-span-2">
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Email *</label>
                    <input name="email" type="email" value={form.email} onChange={handleChange} className={inputClass("email")} placeholder="your@email.com" />
                    {errors.email && <p className="text-destructive text-xs mt-1 font-body">{errors.email}</p>}
                  </div>
                  <div className="md:col-span-2">
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Address *</label>
                    <textarea name="address" value={form.address} onChange={handleChange} rows={3} className={inputClass("address")} placeholder="House no, Street, Landmark" />
                    {errors.address && <p className="text-destructive text-xs mt-1 font-body">{errors.address}</p>}
                  </div>
                  <div>
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">City *</label>
                    <input name="city" value={form.city} onChange={handleChange} className={inputClass("city")} placeholder="City" />
                    {errors.city && <p className="text-destructive text-xs mt-1 font-body">{errors.city}</p>}
                  </div>
                  <div>
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">State *</label>
                    <input name="state" value={form.state} onChange={handleChange} className={inputClass("state")} placeholder="State" />
                    {errors.state && <p className="text-destructive text-xs mt-1 font-body">{errors.state}</p>}
                  </div>
                  <div>
                    <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1 block">Pincode *</label>
                    <input name="pincode" value={form.pincode} onChange={handleChange} className={inputClass("pincode")} placeholder="110001" maxLength={6} />
                    {errors.pincode && <p className="text-destructive text-xs mt-1 font-body">{errors.pincode}</p>}
                  </div>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div className="bg-card border border-border rounded-sm p-6">
                <h3 className="font-display text-xl font-semibold text-foreground mb-4">Payment Method</h3>
                <div className="space-y-3">
                  <label
                    className={`flex items-center gap-3 p-4 border rounded-sm cursor-pointer transition-colors ${paymentMethod === "razorpay" ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground"}`}
                  >
                    <input type="radio" name="paymentMethod" value="razorpay" checked={paymentMethod === "razorpay"} onChange={() => setPaymentMethod("razorpay")} className="accent-primary" />
                    <CreditCard size={20} className="text-primary" />
                    <div>
                      <p className="font-body text-sm font-medium text-foreground">Pay Online</p>
                      <p className="font-body text-xs text-muted-foreground">UPI, Cards, Net Banking, Wallets</p>
                    </div>
                  </label>
                  <label
                    className={`flex items-center gap-3 p-4 border rounded-sm cursor-pointer transition-colors ${paymentMethod === "cod" ? "border-primary bg-primary/5" : "border-border hover:border-muted-foreground"}`}
                  >
                    <input type="radio" name="paymentMethod" value="cod" checked={paymentMethod === "cod"} onChange={() => setPaymentMethod("cod")} className="accent-primary" />
                    <Banknote size={20} className="text-primary" />
                    <div>
                      <p className="font-body text-sm font-medium text-foreground">Cash on Delivery</p>
                      <p className="font-body text-xs text-muted-foreground">Pay when you receive your order</p>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Order Summary */}
            <div className="bg-card border border-border rounded-sm p-6 h-fit sticky top-32">
              <h3 className="font-display text-xl font-semibold text-foreground mb-6">Order Summary</h3>
              <div className="space-y-3 mb-6">
                {items.map(({ product, quantity }) => (
                  <div key={product.id} className="flex justify-between font-body text-sm">
                    <span className="text-muted-foreground truncate mr-2">{product.name} × {quantity}</span>
                    <span className="text-foreground flex-shrink-0">₹{(product.price * quantity).toLocaleString()}</span>
                  </div>
                ))}
                <div className="border-t border-border pt-3 flex justify-between font-body text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-foreground">{shipping === 0 ? "Free" : `₹${shipping}`}</span>
                </div>
                <div className="border-t border-border pt-3 flex justify-between">
                  <span className="font-display text-lg font-semibold text-foreground">Total</span>
                  <span className="font-display text-lg font-semibold text-foreground">₹{finalTotal.toLocaleString()}</span>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isProcessing}
                className="w-full gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm py-6 hover:opacity-90 border-none disabled:opacity-50"
              >
                {isProcessing ? (
                  <><Loader2 size={18} className="mr-2 animate-spin" /> Processing...</>
                ) : paymentMethod === "cod" ? (
                  <><Banknote size={18} className="mr-2" /> Place Order (COD)</>
                ) : (
                  <><CreditCard size={18} className="mr-2" /> Pay ₹{finalTotal.toLocaleString()}</>
                )}
              </Button>
              <p className="text-center font-body text-[10px] text-muted-foreground mt-3">
                {paymentMethod === "cod" ? "💵 Pay cash when your order arrives" : "🔒 Secure payment powered by Razorpay"}
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
