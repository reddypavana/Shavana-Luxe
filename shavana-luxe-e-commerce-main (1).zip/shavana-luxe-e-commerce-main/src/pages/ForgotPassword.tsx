import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) toast.error(error.message);
    else setSent(true);
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-champagne">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md bg-card border border-border rounded-sm p-8 mx-4">
        <Link to="/login" className="inline-flex items-center gap-1 font-body text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft size={14} /> Back to login
        </Link>
        <h2 className="font-display text-2xl font-semibold text-foreground mb-2">Reset Password</h2>
        {sent ? (
          <p className="font-body text-muted-foreground">Check your email for a password reset link.</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <p className="font-body text-sm text-muted-foreground">Enter your email to receive a reset link.</p>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-border rounded-sm px-3 py-2.5 font-body text-sm bg-transparent text-foreground"
              placeholder="your@email.com"
              required
            />
            <Button type="submit" disabled={loading} className="w-full gold-gradient text-primary-foreground font-body uppercase tracking-wider text-sm py-6 hover:opacity-90 border-none disabled:opacity-50">
              {loading ? "Sending..." : "Send Reset Link"}
            </Button>
          </form>
        )}
      </motion.div>
    </div>
  );
};

export default ForgotPassword;
