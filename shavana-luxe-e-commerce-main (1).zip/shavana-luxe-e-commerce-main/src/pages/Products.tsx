import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { SlidersHorizontal, X } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { products, categories, searchProducts } from "@/data/products";
import { motion } from "framer-motion";

const priceRanges = [
  { label: "All", min: 0, max: Infinity },
  { label: "Under ₹1,000", min: 0, max: 999 },
  { label: "₹1,000 - ₹2,500", min: 1000, max: 2500 },
  { label: "₹2,500 - ₹5,000", min: 2500, max: 5000 },
  { label: "Above ₹5,000", min: 5000, max: Infinity },
];

const Products = () => {
  const [searchParams] = useSearchParams();
  const categoryParam = searchParams.get("category") || "";
  const searchParam = searchParams.get("search") || "";

  const [selectedCategory, setSelectedCategory] = useState(categoryParam);
  const [selectedPrice, setSelectedPrice] = useState(0);
  const [sortBy, setSortBy] = useState("default");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let result = searchParam ? searchProducts(searchParam) : [...products];

    if (selectedCategory) {
      result = result.filter((p) => p.category === selectedCategory);
    }

    const priceRange = priceRanges[selectedPrice];
    result = result.filter((p) => p.price >= priceRange.min && p.price <= priceRange.max);

    switch (sortBy) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        result.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
    }
    return result;
  }, [selectedCategory, selectedPrice, sortBy, searchParam]);

  const title = searchParam
    ? `Search: "${searchParam}"`
    : selectedCategory
    ? categories.find((c) => c.slug === selectedCategory)?.name || "Products"
    : "All Products";

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-champagne py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="font-body text-gold text-sm uppercase tracking-[0.3em] mb-2">Collection</p>
          <h1 className="font-display text-4xl font-semibold text-foreground">{title}</h1>
          <p className="font-body text-muted-foreground mt-2">{filtered.length} products</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filter bar */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 font-body text-sm uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors"
          >
            <SlidersHorizontal size={16} />
            Filters
          </button>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="font-body text-sm bg-transparent border border-border rounded-sm px-3 py-2 text-foreground"
          >
            <option value="default">Sort By</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            className="mb-8 p-6 bg-champagne rounded-sm"
          >
            <div className="flex flex-wrap gap-8">
              {/* Category */}
              <div>
                <h4 className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-3">Category</h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedCategory("")}
                    className={`font-body text-sm px-3 py-1.5 rounded-sm border transition-colors ${
                      !selectedCategory
                        ? "bg-foreground text-background border-foreground"
                        : "border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    All
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.slug)}
                      className={`font-body text-sm px-3 py-1.5 rounded-sm border transition-colors ${
                        selectedCategory === cat.slug
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price */}
              <div>
                <h4 className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-3">Price Range</h4>
                <div className="flex flex-wrap gap-2">
                  {priceRanges.map((range, i) => (
                    <button
                      key={range.label}
                      onClick={() => setSelectedPrice(i)}
                      className={`font-body text-sm px-3 py-1.5 rounded-sm border transition-colors ${
                        selectedPrice === i
                          ? "bg-foreground text-background border-foreground"
                          : "border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {range.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {(selectedCategory || selectedPrice > 0) && (
              <button
                onClick={() => {
                  setSelectedCategory("");
                  setSelectedPrice(0);
                }}
                className="mt-4 font-body text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground flex items-center gap-1"
              >
                <X size={12} /> Clear All Filters
              </button>
            )}
          </motion.div>
        )}

        {/* Products Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="font-display text-2xl text-muted-foreground">No products found</p>
            <p className="font-body text-sm text-muted-foreground mt-2">Try adjusting your filters</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;
